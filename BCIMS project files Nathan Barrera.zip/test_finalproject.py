import pytest
from finalproject import Customer

# Testing the Customer class
class TestCustomer:
    @pytest.fixture
    def sample_customer(self):
        customer = Customer(1, "John Doe")
        return customer

    def test_add_purchase(self, sample_customer):
        sample_customer.add_purchase("Book Title 1", "fiction")
        sample_customer.add_purchase("Book Title 2", "non-fiction")
        assert len(sample_customer.purchase_history) == 2
        assert sample_customer.purchase_history[0] == ("Book Title 1", "fiction")
        assert sample_customer.purchase_history[1] == ("Book Title 2", "non-fiction")

    def test_calculate_preference_score_no_purchases(self, sample_customer):
        scores = sample_customer.calculate_preference_score()
        assert scores['fiction'] == 0.0
        assert scores['non-fiction'] == 0.0

    def test_calculate_preference_score_with_purchases(self, sample_customer):
        sample_customer.add_purchase("Book Title 1", "fiction")
        sample_customer.add_purchase("Book Title 2", "fiction")
        sample_customer.add_purchase("Book Title 3", "non-fiction")
        scores = sample_customer.calculate_preference_score()
        assert scores['fiction'] == (2 / 3) * 10.0
        assert scores['non-fiction'] == (1 / 3) * 10.0

# Run the tests
if __name__ == "__main__":
    pytest.main()
