# Final Project (Nathan Barrera)

## Bookstore Customer Information Management System (BCIMS)
This project is a desktop application for bookstores to manage
their customer data, including their purchase history and reading preferences

## Install required libraries
Ensure that you are in the main directory and 
run the following:

_This must be done before you can run the application
if you are not using the included venv._

```shell
$ pip install -r requirements.txt
```
or 
```shell
$ pip install PILLOW
$ pip install pytest
```
## To run the program
Click the green triangle run icon in the 
top-right corner of the PyCharm window.
or
```shell
$ python3 project.py
```

## Functionality
### Add Purchase
Adds a customer's purchase record (book title and genre)

### Edit Customer
Edits the selected customers name and data


### Delete Customer
Removes the selected customer from the system

### View Purchase History: Shows all purchases made by selected customer

### Search Customer
Searches for customer by their name

### Exit
The application will be closed when the Exit
button is clicked.

## Data Files
### Customers.json
This contains customer data on past purchases
in the following format:
```json
[{"customer_id": 1, "name": "Nathan", "purchase_history": [["Harry Potter", "fiction"]]}, {"customer_id": 2, "name": "John", "purchase_history": [["Clifford", "non-fiction"], ["Art of Silence", "fiction"]]}, {"customer_id": 3, "name": "Elva", "purchase_history": [["Computer Information", "non-fiction"], ["Amphibian Physiology", "non-fiction"], ["Hunger Games", "fiction"]]}]
```

### Class Method Calls
The GUI calls methods from the Customer class for various functionalities:
add_purchase(book_title, genre) is called when adding a new purchase.
calculate_preference_score() is used to calculate the reading preferences based on the purchase history.

### Class Created
## Customer Class
Attributes:
customer_id: Customer's unique identifier.
name: Customer's name.
purchase_history: List of tuples containing book titles and genres.

Methods:
add_purchase(): Adds a book purchase to the customer's history.
calculate_preference_score(): Calculates the customer's genre preferences.
to_dict(): Converts customer data to a dictionary format for JSON storage.
from_dict(): Creates a Customer instance from dictionary data.

## Auto Testing
Run the following command to test the 
test_accounts.py file.

```shell
$ pytest -v test_finalproject.py
```
