#Nathan Barrera CIS345 12pm TUE THU
import tkinter as tk
from tkinter import messagebox, PhotoImage, ttk
import json
import os

class Customer:
    def __init__(self, customer_id, name):
        self.customer_id = customer_id
        self.name = name
        self.purchase_history = []

    def add_purchase(self, book_title, genre):
        self.purchase_history.append((book_title, genre))

    def calculate_preference_score(self):
        fiction_count = sum(1 for _, genre in self.purchase_history if genre == "fiction")
        non_fiction_count = sum(1 for _, genre in self.purchase_history if genre == "non-fiction")
        total_count = fiction_count + non_fiction_count
        fiction_score = (fiction_count / total_count) * 10.0 if total_count > 0 else 0.0
        non_fiction_score = (non_fiction_count / total_count) * 10.0 if total_count > 0 else 0.0
        return {'fiction': fiction_score, 'non-fiction': non_fiction_score}

    def to_dict(self):
        return {
            "customer_id": self.customer_id,
            "name": self.name,
            "purchase_history": self.purchase_history
        }

    @classmethod
    def from_dict(cls, data):
        customer = cls(data['customer_id'], data['name'])
        customer.purchase_history = data['purchase_history']
        return customer

class BCIMSGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BCIMS - Bookstore")
        self.geometry("1000x900")

        self.load_image()

        # Widgets
        self.name_label = tk.Label(self, text="Customer Name:")
        self.name_entry = tk.Entry(self)
        self.book_label = tk.Label(self, text="Book Title:")
        self.book_entry = tk.Entry(self)
        self.genre_label = tk.Label(self, text="Genre:")
        self.genre_combo = ttk.Combobox(self, values=["fiction", "non-fiction"], state="readonly")
        self.add_button = tk.Button(self, text="Add Purchase", command=self.add_purchase)
        self.edit_button = tk.Button(self, text="Edit", command=self.edit_customer)
        self.delete_button = tk.Button(self, text="Delete", command=self.delete_customer)
        self.search_button = tk.Button(self, text="Search", command=self.search_customer)
        self.view_history_button = tk.Button(self, text="View Purchase History", command=self.view_purchase_history)
        self.exit_button = tk.Button(self, text="Exit", command=self.destroy)

        # Treeview for displaying customers and their preference scores
        self.customers_tree = ttk.Treeview(self, columns=("Name", "Fiction", "Non-Fiction"), show="headings")
        self.customers_tree.heading("Name", text="Customer Name")
        self.customers_tree.heading("Fiction", text="Fiction Score")
        self.customers_tree.heading("Non-Fiction", text="Non-Fiction Score")
        self.customers_tree.column("Name", anchor=tk.W, width=150)
        self.customers_tree.column("Fiction", anchor=tk.CENTER, width=100)
        self.customers_tree.column("Non-Fiction", anchor=tk.CENTER, width=100)

        # Layout
        self.logo_label.grid(row=0, column=0, columnspan=4)
        self.name_label.grid(row=1, column=0)
        self.name_entry.grid(row=1, column=1)
        self.book_label.grid(row=2, column=0)
        self.book_entry.grid(row=2, column=1)
        self.genre_label.grid(row=3, column=0)
        self.genre_combo.grid(row=3, column=1)
        self.add_button.grid(row=4, column=0)
        self.edit_button.grid(row=4, column=1)
        self.delete_button.grid(row=4, column=2)
        self.search_button.grid(row=4, column=3)
        self.view_history_button.grid(row=4, column=4)
        self.exit_button.grid(row=5, column=3)
        self.customers_tree.grid(row=6, column=0, columnspan=5, sticky="nsew")

        self.data_file = 'customers.json'
        self.load_data()

    def load_image(self):
        try:
            image_path = os.path.join(os.path.dirname(__file__), 'bookstore.png')
            self.photo = PhotoImage(file=image_path)
            self.logo_label = tk.Label(self, image=self.photo)
        except Exception as e:
            print(f"Error loading image: {e}")
            self.logo_label = tk.Label(self, text="Bookstore")

    def add_purchase(self):
        name = self.name_entry.get()
        book_title = self.book_entry.get()
        genre = self.genre_combo.get()

        if name and book_title and genre:
            customer = next((cust for cust in self.customers if cust.name == name), None)
            if customer:
                customer.add_purchase(book_title, genre)
            else:
                customer_id = len(self.customers) + 1
                customer = Customer(customer_id, name)
                customer.add_purchase(book_title, genre)
                self.customers.append(customer)
            self.save_data()
            self.update_treeview()
            self.name_entry.delete(0, tk.END)
            self.book_entry.delete(0, tk.END)
            self.genre_combo.set('')

    def edit_customer(self):
        selected_item = self.customers_tree.selection()
        if selected_item:
            name = self.customers_tree.item(selected_item)['values'][0]
            new_name = self.name_entry.get()
            if new_name:
                customer = next((cust for cust in self.customers if cust.name == name), None)
                if customer:
                    customer.name = new_name
                    self.save_data()
                    self.update_treeview()
                self.name_entry.delete(0, tk.END)

    def delete_customer(self):
        selected_item = self.customers_tree.selection()
        if selected_item:
            name = self.customers_tree.item(selected_item)['values'][0]
            self.customers = [cust for cust in self.customers if cust.name != name]
            self.customers_tree.delete(selected_item)
            self.save_data()

    def search_customer(self):
        search_term = self.name_entry.get()
        if search_term:
            found_customers = [cust for cust in self.customers if search_term.lower() in cust.name.lower()]
            self.update_treeview(found_customers)
        else:
            self.update_treeview()

    def view_purchase_history(self):
        selected_item = self.customers_tree.selection()
        if selected_item:
            name = self.customers_tree.item(selected_item)['values'][0]
            customer = next((cust for cust in self.customers if cust.name == name), None)
            if customer:
                self.show_purchase_history(customer)

    def show_purchase_history(self, customer):
        history_window = tk.Toplevel(self)
        history_window.title(f"Purchase History for {customer.name}")
        history_list = ttk.Treeview(history_window, columns=("Title", "Genre"), show="headings")
        history_list.heading("Title", text="Book Title")
        history_list.heading("Genre", text="Genre")
        history_list.pack(expand=True, fill="both")

        for book_title, genre in customer.purchase_history:
            history_list.insert("", "end", values=(book_title, genre))

    def load_data(self):
        try:
            with open(self.data_file, 'r') as file:
                data = json.load(file)
                self.customers = [Customer.from_dict(cust) for cust in data]
        except FileNotFoundError:
            self.customers = []
        self.update_treeview()

    def save_data(self):
        with open(self.data_file, 'w') as file:
            json.dump([cust.to_dict() for cust in self.customers], file)

    def update_treeview(self, customers=None):
        customers = customers or self.customers
        self.customers_tree.delete(*self.customers_tree.get_children())
        for cust in customers:
            scores = cust.calculate_preference_score()
            self.customers_tree.insert("", "end", values=(cust.name, f"{scores['fiction']:.1f}", f"{scores['non-fiction']:.1f}"))

if __name__ == "__main__":
    app = BCIMSGUI()
    app.mainloop()
